package com.example.assjava5.constant;

public class SessionArr {
    public static final String CURRENT_USER = "currentUser";
    public static final String CURRENT_USERAdmin = "currentAdmin";
}
